package org.example.utils;

public class Constants {

    public static final String FILE_PATH_PERSOANA = "persoane.txt";
    public static final String FILE_PATH_DUCK = "ducks.txt";
    public static final String FILE_PATH_FRIENDSHIP = "friendships.txt";

    public static final double CONSTANT_TIME = 1e6;

    public static final String PATH_DB = "jdbc:postgresql://localhost:5432/duckSocialNetwork";
    public static final String USERNAME = "postgres";
    public static final String PASSWORD = "Flavius10";

}
