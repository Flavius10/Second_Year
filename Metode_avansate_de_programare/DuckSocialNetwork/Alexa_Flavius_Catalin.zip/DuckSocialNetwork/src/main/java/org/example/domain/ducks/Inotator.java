package org.example.domain.ducks;

public interface Inotator {
    void inoata();
}
