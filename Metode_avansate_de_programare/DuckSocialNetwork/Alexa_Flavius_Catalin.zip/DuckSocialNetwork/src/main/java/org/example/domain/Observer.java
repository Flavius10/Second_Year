package org.example.domain;

public interface Observer {

    void update(String message);

}
