package org.example.domain.ducks;

public interface Zburator {
    void zboara();
}
