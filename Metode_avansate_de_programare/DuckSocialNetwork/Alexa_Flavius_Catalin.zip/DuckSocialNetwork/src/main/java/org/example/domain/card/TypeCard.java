package org.example.domain.card;

public enum TypeCard {
    FLYING, SWIMMING, FLYING_AND_SWIMMING
}
