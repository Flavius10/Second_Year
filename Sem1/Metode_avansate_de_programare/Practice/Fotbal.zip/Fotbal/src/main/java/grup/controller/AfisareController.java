package grup.controller;

import grup.domain.Meci;
import grup.domain.User;
import grup.service.ServiceEveniment;
import grup.service.ServiceMeciuri;
import javafx.fxml.FXML;
import javafx.scene.control.Label;


public class AfisareController {

    @FXML
    private Label numeEchipaGazda;

    @FXML
    private Label numeEchipaVenita;

    @FXML
    private Label scorEchipaGazda;

    @FXML
    private Label scorEchipaVenita;

    private ServiceEveniment serviceEveniment;
    private Meci meci;

    public void setService(ServiceEveniment service, Meci meci) {
        this.serviceEveniment = serviceEveniment;
        this.meci = meci;

        this.numeEchipaGazda.setText(this.meci.getNumeEchipaGazda().toString());
        this.numeEchipaVenita.setText(this.meci.getNumeEchipaOaspeti().toString());
        this.scorEchipaVenita.setText(this.meci.getScorEchipaGazda().toString());
        this.scorEchipaGazda.setText(this.meci.getScorEchipaOaspeti().toString());
    }

    public void initialize(){
    }
}
