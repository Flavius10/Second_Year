package grup;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage ) throws Exception {

        String url = "jdbc:postgresql://localhost:5432/restaurant_db";
        String user = "postgres";
        String pass = "Flavius10";

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/test.fxml"));

        Scene scene = new Scene(fxmlLoader.load(), 400, 300);
        stage.setTitle("Test Rapid");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}